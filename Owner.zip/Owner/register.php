<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Owner</title>
  <link rel="stylesheet" href="node_modules/font-awesome/css/font-awesome.min.css" />
  <link rel="stylesheet" href="node_modules/perfect-scrollbar/dist/css/perfect-scrollbar.min.css" />
  <link rel="stylesheet" href="css/style.css" />
  <link rel="shortcut icon" href="images/favicon.png" />
</head>

<body>
  <div class="container-scroller">
    <div class="container-fluid">
      <div class="row">
        <div class="content-wrapper full-page-wrapper d-flex align-items-center">
          <div class="card col-lg-4 offset-lg-4">
            <div class="card-block">
              <h3 class="card-title text-primary text-left mb-5 mt-4"><center>Register</center></h3>

              <form method="post" enctype="multipart/form-data">
                <div class="form-group">
                  <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-user"></i></span>
                    <input type="text" name="username" class="form-control p_input" placeholder="Username" required="required">
                  </div>
                </div>
                <div class="form-group">
                  <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-envelope-open"></i></span>
                    <input type="email" name="email" class="form-control p_input" placeholder="Email" required="required">
                  </div>
                </div>
                <div class="form-group">
                  <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-envelope-open"></i></span>
                    <input type="file" name="file" class="form-control p_input" placeholder="Photo" required="required">
                  </div>
                </div>
                <div class="form-group">
                  <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                    <input type="password" name="password" class="form-control p_input" placeholder="Password" required="required">
                  </div>
                </div>
                
                <input type="submit" name="register" class="btn btn-primary" value="Register">
                <br><br>
                <h5>Already registered<a href="index.php"> Login</a></h5>

<?php
include('connection.php');
if(isset($_POST['register']))
{
  extract($_POST);

  $df=uniqid();

      $exname=$_FILES['file']['name'];
      $size=$_FILES['file']['size'];
      $type=$_FILES['file']['type'];
      $temp=$_FILES['file']['tmp_name'];
      $dst="".$df.$exname;
      move_uploaded_file($temp,"../Images/Owner/".$dst);


  $query=mysqli_query($con,"INSERT INTO owner (name,email,photo,password) VALUES ('$username','$email','$dst','$password') ") or die(mysqli_error($con));
  if ($query)
   {
     echo "<script>";
      echo "alert('Owner Account Created Successfully');";
      echo "window.location.href='register.php'";
      echo "</script";
  }
  else
    {
      echo "<script>";
      echo "alert('Account Not Created');";
      echo "window.location.href='register.php'";
      echo "</script";
    }

}
?>

              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="../node_modules/jquery/dist/jquery.min.js"></script>
  <script src="../node_modules/tether/dist/js/tether.min.js"></script>
  <script src="../node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
  <script src="../node_modules/perfect-scrollbar/dist/js/perfect-scrollbar.jquery.min.js"></script>
  <script src="../js/misc.js"></script>
</body>

</html>