<?php
include 'header.php';
?>
                
                <div class="content-wrapper">
                    <h3 class="text-primary mb-4">View Society</h3>
                    <div class="row mb-2">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-block">
                                <?php
                                include 'connection.php';
  if(isset($_GET['society_email']))
  {
   
   
   $query = mysqli_query($con,"select * from society where email='".$_GET['society_email']."' ") or die(mysqli_error($con));
      
          $result = mysqli_fetch_array($query);
          extract($result);
  
  
    ?>  
                                    <h5 class="card-title mb-4">View Society</h5>
                                    <form class="forms-sample" method="post" enctype="multipart/form-data">
                                        <div class="form-group">
                                         
                                            <label for="exampleInputEmail1">Society Name</label>
                                            <input type="text" name="name" class="form-control p-input" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo $result['society_name']; ?>" required="">
                                            <small id="emailHelp" class="form-text text-muted text-success"></small>
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Email</label>
                                            <input type="email" name="email" class="form-control p-input" id="exampleInputPassword1" value="<?php echo $result['email']; ?>" required="required">
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Contact</label>
                                            <input type="text" name="contact" class="form-control p-input" id="exampleInputPassword1" value="<?php echo $result['contact']; ?>" placeholder="Enter contact starting with 0,7,8,9" required="required" minlength="10" maxlength="11" pattern="[7|8|9][0-9]{9}" >
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Registration Code</label>
                                            <input type="text" name="reg_code" class="form-control p-input" id="exampleInputPassword1" value="<?php echo $result['registration_code']; ?>" required="">
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleTextarea">Address</label>
                                            <textarea name="address" class="form-control p-input" id="exampleTextarea" rows="3" required=""><?php echo $result['address']; ?></textarea>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="exampleInputFile">Photo</label>
                                            <input type="file" name="photo" class="form-control-file" id="exampleInputFile" aria-describedby="fileHelp">
                                            <img src="../Images/Society/<?php echo $result['photo']?>" height="120" width="120">
                                            
                                        </div>
                                        
                                       
                                        
                                        <!-- <div class="form-group">
                                            <label for="exampleInputPassword1">Password</label>
                                            <input type="text" name="password" class="form-control p-input" id="exampleInputPassword1" value="<?php echo $result['password']; ?>" required="">
                                        </div> -->

                                        

                                        <div class="col-12" align="center">
                                            <a href="view_society.php"><input type="submit" name="update" class="btn btn-primary" value="Update"></a>
                                            <a href="view_society.php"><input type="button" class="btn btn-warning" value="Cancel"></a>
                                        </div>

                               </form>
                               <?php
                             
                           }
                           ?>


                           <?php
include 'connection.php';
if(isset($_POST['update']))
{
 extract($_POST);

// Code for Update Photo
  $name=$_FILES['photo']['name'];
$size=$_FILES['photo']['size'];
$type=$_FILES['photo']['type'];
$temp=$_FILES['photo']['tmp_name'];
     //$RandomImageName = uniqid();
     //move_uploaded_file($temp,"images/".$pht);
     if($name) {
       
     $upload= "../Images/Society/";
            $imgExt=strtolower(pathinfo($name, PATHINFO_EXTENSION));
            $valid_ext= array('jpg','png','jpeg' );
            $userpic= rand(1000,1000000).".".$imgExt;
            unlink($upload.$row['photo']);
            move_uploaded_file($temp,$upload.$userpic);
   }
   else
   {
    $userpic=$result['photo'];
   }


 $query=mysqli_query($con,"update society set
 society_name='".$_POST['name']."',
 email='".$_POST['email']."',
 contact='".$_POST['contact']."',
 registration_code='".$_POST['reg_code']."',
 address='".$_POST['address']."',
 photo='".$userpic."'
 
 where email='".$_GET['society_email']."' ") or die(mysqli_error($con));
 if($query)
                          {
       echo '<script type="text/javascript">';
       echo " alert('Society Updated Successfully');";
       echo 'window.location.href = "view_society.php";';
       echo '</script>';
  
                      }
                     else
                     {
       echo '<script type="text/javascript">';
       echo " alert('No Updated Successfully');";
       echo 'window.location.href = "view_society.php";';
       echo '</script>';
  
                     }
}


?>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                    include 'footer.php';

                ?>