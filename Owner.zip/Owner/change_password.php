<?php
include 'header.php';
?>
                
                <div class="content-wrapper">
                    <h3 class="text-primary mb-4">Change Password</h3>
                    <div class="row mb-2">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-block">
                                    <h5 class="card-title mb-4">Change Password</h5>
                                    <form class="forms-sample" method="post" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Old Password</label>
                                            <input type="password" name="old_pass" class="form-control p-input" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Old Password" required="required">
                                            <small id="emailHelp" class="form-text text-muted text-success"></small>
                                        </div>
                                        
                                        
                                                                                                             
                                      <div class="form-group">
                                            <label for="exampleInputEmail1">New Password</label>
                                            <input type="password" name="new_pass" class="form-control p-input" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter New Password" required="required">
                                            <small id="emailHelp" class="form-text text-muted text-success"></small>
                                        </div>



                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Confirm Password</label>
                                            <input type="password" name="conf_pass" class="form-control p-input" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Confirm Password" required="required">
                                            <small id="emailHelp" class="form-text text-muted text-success"></small>
                                        </div>
                                        


                                        <div class="col-12">
                                            <button type="submit" name="change" class="btn btn-primary">Change</button>
                                            <a href="home.php" class="btn btn-danger">Cancel</a>
                                        </div>






                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                    include 'footer.php';

                ?>



                <?php

if(isset($_POST['change']))
{
  extract($_POST);
   $query='select * from owner where email="'.$_SESSION['email'].'" and password="'.$_POST['old_pass'].'"';


   $res = mysqli_query($con,$query) or die(mysqli_error($con));
   
   
   if(mysqli_num_rows($res)>0)
   {
    
         if($_POST['new_pass']==$_POST['conf_pass'])
           {
          $updt = 'update owner set password="'.$_POST['new_pass'].'" where email="'.$_SESSION['email'].'" ';

            $res1=mysqli_query($con,$updt) or die(mysqli_error($con));

              if($res1)
              {
                echo "<script>";
                echo "alert('Password Changed');";
                echo "window.location.href='home.php'";
                echo "</script>";
              }
              else
              {

                echo "Password Not Changed";
                
              }
            }
          else
      {
             echo "<script>";
             echo "alert('Password Not Matched');";
               echo "window.location.href='change_password.php'";
             echo "</script>";
      }
    }
    
else
      {
       echo "<script>";
       echo "alert('Old Password is Wrong');";
        echo "window.location.href='change_password.php'";
        echo "</script>";
      }
    
}
?>