<input type="text" name="marks[]" class="form-control p-input" id='textbox1' aria-describedby="emailHelp" placeholder="Enter Marks Waightage">
 <small id="emailHelp" class="form-text text-muted text-success"></small>
 <input type="text" name="marks[]" class="form-control p-input" id='textbox1' aria-describedby="emailHelp" placeholder="Enter Marks Waightage">
 <small id="emailHelp" class="form-text text-muted text-success"></small>
 


