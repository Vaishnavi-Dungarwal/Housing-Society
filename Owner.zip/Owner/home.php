 <?php
include 'header.php';
?> 
                
                <div class="content-wrapper">
                    <h3 class="text-primary mb-4">Dashboard</h3>
                    <div class="row">



                    	<div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 mb-4">
                            <div class="card">
                                <div class="card-block">
                                <?php
                                    include 'connection.php';

                                    $count_society = mysqli_query($con,"select DISTINCT society_name from society") or die(myslqi_error($con));
                                    $count_society=mysqli_num_rows($count_society);

                                ?>  
                                    <h4 class="card-title font-weight-normal text-success"><?php echo "$count_society"; ?></h4>
                                    <p class="card-text">Society</p>
                                    <div class="progress">
                                       
                                    </div>
                                </div>
                            </div>
                        </div>





                        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 mb-4">
                            <div class="card">
                                <div class="card-block">
                                <?php
                                    include 'connection.php';

                                    $count_user = mysqli_query($con,"select DISTINCT name from user") or die(myslqi_error($con));
                                    $cnt_user=mysqli_num_rows($count_user);

                                ?>  
                                    <h4 class="card-title font-weight-normal text-success"><?php echo "$cnt_user"; ?></h4>
                                    <p class="card-text">User</p>
                                    <div class="progress">
                                       
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 mb-4">
                            <div class="card">
                                <div class="card-block">
                                <?php
                                    include 'connection.php';

        $count_tax = mysqli_query($con,"select DISTINCT SUM(tax) AS sum from tax_paid") or die(myslqi_error($con));
                                    $cnt_tax=mysqli_fetch_assoc($count_tax);


                                ?>  
                                    <h4 class="card-title font-weight-normal text-success">
                                        <?php if($cnt_tax['sum']>0)
                                        {
                                          echo $cnt_tax['sum'];
                                        }
                                        else
                                        {
                                          echo '0';                 
                                        }
                                        ?>
                                        </h4>
                                    <p class="card-text">Paid Tax</p>
                                    <div class="progress">
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                      
                       
                    </div>

                    
                    <!-- <div class="row">
                        <div class="col-lg-6  mb-4">
                            <div class="card">
                                <div class="card-block">
                                    <h5 class="card-title mb-4">Sales</h5>
                                    <canvas id="lineChart" style="height:250px"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6  mb-4">
                            <div class="card">
                                <div class="card-block">
                                    <h5 class="card-title mb-4">Customer Satisfaction</h5>
                                    <canvas id="doughnutChart" style="height:250px"></canvas>
                                </div>
                            </div>
                        </div>
                    </div> -->
                   <!--  <div class="row">
                        <div class="col-lg-6 mb-4">
                            <div class="card">
                                <div class="card-block">
                                    <h5 class="card-title mb-4">Payments</h5>
                                    <table class="table">
                                        <thead class="text-primary">
                                            <tr>
                                                <th><i class="fa fa-user ml-2"></i></th>
                                                <th>User</th>
                                                <th>Item</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <th><img src="images/profile.jpg" alt="profile" class="rounded-circle" width="40"
                                                        height="40" /></th>
                                                <td>Larry</td>
                                                <td>Acer</td>
                                                <td><span class="badge badge-success">Success</span></td>
                                            </tr>
                                            <tr>
                                                <th><img src="images/profile.jpg" alt="profile" class="rounded-circle" width="40"
                                                        height="40" /></th>
                                                <td>Larry</td>
                                                <td>Acer</td>
                                                <td><span class="badge badge-danger">Failed</span></td>
                                            </tr>
                                            <tr>
                                                <th><img src="images/profile.jpg" alt="profile" class="rounded-circle" width="40"
                                                        height="40" /></th>
                                                <td>Larry</td>
                                                <td>Acer</td>
                                                <td><span class="badge badge-primary">Processing</span></td>
                                            </tr>
                                            <tr>
                                                <th><img src="images/profile.jpg" alt="profile" class="rounded-circle" width="40"
                                                        height="40" /></th>
                                                <td>Larry</td>
                                                <td>Acer</td>
                                                <td><span class="badge badge-success">Success</span></td>
                                            </tr>
                                            <tr>
                                                <th><img src="images/profile.jpg" alt="profile" class="rounded-circle" width="40"
                                                        height="40" /></th>
                                                <td>Larry</td>
                                                <td>Acer</td>
                                                <td><span class="badge badge-danger">Failed</span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 mb-4">
                            <div class="card">
                                <div class="card-block">
                                    <h5 class="card-title"></h5>
                                    <div id="map" style="min-height:415px;"></div>
                                </div>
                            </div>
                        </div>
                    </div> -->
                </div>
                
                <?php
                    include 'footer.php';
                ?>
