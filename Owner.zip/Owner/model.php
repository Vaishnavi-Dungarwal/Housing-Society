<?php
if(isset($_POST["department"])){
   
	 $str = $_POST['department'];
				
     include "connection.php"; 


	  ?>
      
	  <?php	
	
	   $select1=mysqli_query($con,"select DISTINCT year from year where department='".$str."'") or die(mysqli_error($con));
	   echo "<option value=''>---select year ---</option>";
	 while($sele1=mysqli_fetch_array($select1))
{
	echo"<option value=\"{$sele1['year']}\">{$sele1['year']}</option>";

	}	 
		
}

?>