<?php
 include 'header.php';
?>
                <div class="content-wrapper">
                    <h3 class="text-primary mb-4">Registered College Details</h3>
                    

                    <div class="row mb-2">
                        <div class="col-md-12 col-xs-12">
                            <div class="card">
                                <div class="card-block">
                                    <!-- <h5 class="card-title mb-4">Advanced Table</h5> -->
                                    <div class="table-responsive">
                                        <table id="example" class="table table-hover" cellspacing="0" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>Id</th>
                                                    <th>Name</th>               
                                                    <th>Email</th>
                                                    <th>Contact</th>
                                                    <th>Photo</th>
                                                    <th>Affili. Code</th>
                                                    <th>Center Code</th>
                                                    <th>Address</th>
                                                    <!-- <th>Password</th> -->
                                                    <th>Year</th>
                                                    <th>Status</th>
                                                    <th>Action</th>

                                                </tr>
                                            </thead>

                                            <tbody>
                                                    <?php
                                                    include 'connection.php';
                                                    $disp=mysqli_query($con,"select * from college where status='Not-approved' ") or die(mysqli_error($con));
                                                    $count=0;
                                                    while ($fetch=mysqli_fetch_array($disp))
                                                     {
                                                            extract($fetch);


                                                ?>  
                                                    <tr>
                                                        <td><?php echo $id ?></td>
                                                        <td><?php echo $fetch['name'];?></td>
                                                        <td><?php echo $fetch['email'];?></td>
                                                        <td><?php echo $fetch['contact'];?></td>                                                       
                                                        <td><img src="../College/images/<?php echo $fetch['photo']; ?>" height="80" width="80"></td>
                                                        <td><?php echo $fetch['aff_code'];?></td>
                                                        <td><?php echo $fetch['center_code'];?></td>
                                                        <td><?php echo $fetch['address'];?></td>
                                                        <!-- <td><?php //echo $fetch['password'];?></td> -->
                                                        <td><?php echo $fetch['year'];?></td>
                                                        <td><?php echo $fetch['status'];?></td>
                                                        <td><!-- <a href="reg_approve.php?id=<?=$id ?>" class="fa fa-thumbs-o-up fa-2x text-success" type="submit" name="view"  data-placement="bottom" title="approve" data-toggle="tooltip"></a> -->
                                            
                                                        <!-- <a href="reg_disapproved.php?id=<?=$id ?>" class="fa fa-thumbs-o-down fa-2x text-danger" type="submit" name="view"  data-placement="bottom" title="disapprove" data-toggle="tooltip" style="padding-left:10px"></a> -->

                                                        <a href="set_approved.php?id=<?=$id ?>" class="fa fa-thumbs-o-up fa-2x text-success" type="submit" name="view"  data-placement="bottom" title="Approve" data-toggle="tooltip" style="padding-left:10px"></a>
                                            
                                                        <a href="view-approved.php?id=<?=$id ?>" class="fa fa-eye fa-2x text-info" type="submit" name="view"  data-placement="bottom" title="view" data-toggle="tooltip" style="padding-left:10px"></a>

                                                        <a href="update-college.php?id=<?=$id ?>" class="fa fa-edit fa-2x text-success" type="submit" name="Update"  data-placement="bottom" title="Update" data-toggle="tooltip" style="padding-left:10px"></a>
                                            
                                                                                                            
                                                        <a href="delete-college.php?id=<?=$id ?>"  onclick="return confirm('Are you sure you want to delete this record?');"  class="fa fa-trash-o fa-2x text-warning" type="submit" name="delete" style="padding-left:10px" data-placement="bottom" title="delete" data-toggle="tooltip"></a></td>
                                                    </tr>
                                                <?php } ?> 
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            <?php

            include 'footer.php';
            ?>