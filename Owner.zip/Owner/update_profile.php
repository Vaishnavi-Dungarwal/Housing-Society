<?php
include 'header.php';
?>
                
                <div class="content-wrapper">
                    <h3 class="text-primary mb-4">Update Profile</h3>
                    <div class="row mb-2">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-block">
                                <?php
                                include 'connection.php';
  if(isset($_GET['id']))
  {
   
   
   $query = mysqli_query($con,"select * from admin_login where id='".$_GET['id']."' ") or die(mysqli_error($con));
      
          $result = mysqli_fetch_array($query);
          extract($result);
  
  
    ?>  
                                    <h5 class="card-title mb-4">Update</h5>
                                    <form class="forms-sample" method="post" enctype="multipart/form-data">
                                        <div class="form-group">
                                         
                                            <label for="exampleInputEmail1">Name</label>
                                            <input type="text" name="name" class="form-control p-input" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo $result['username']; ?>" required="">
                                            <small id="emailHelp" class="form-text text-muted text-success"></small>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Email</label>
                                            <input type="email" name="email" class="form-control p-input" id="exampleInputPassword1" value="<?php echo $result['email']; ?>" required="">
                                        </div>
                                                                                
                                        
                                        <div class="form-group">
                                            <label for="exampleInputFile">Photo</label>
                                            <input type="file" name="photo" class="form-control-file" id="exampleInputFile" aria-describedby="fileHelp">
                                            <img src="../University/images/<?php echo $result['photo']?>" height="120" width="120">
                                            
                                        </div>
                                       
                                       
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Password</label>
                                            <input type="text" name="password" class="form-control p-input" id="exampleInputPassword1" value="<?php echo $result['password']; ?>" >
                                        </div>

                                        
                                        <div class="col-12" align="center">
                                            <a href="view-profile.php"><input type="submit" name="update" class="btn btn-primary" value="Update"></a>
                                            <a href="view-profile.php"><input type="button" class="btn btn-warning" value="Back"></a>
                                        </div>

                               </form>
                               <?php
                             
                           }
                           ?>


                           <?php
include 'connection.php';
if(isset($_POST['update']))
{
 extract($_POST);

// Code for Update Photo
  $name=$_FILES['photo']['name'];
$size=$_FILES['photo']['size'];
$type=$_FILES['photo']['type'];
$temp=$_FILES['photo']['tmp_name'];
     //$RandomImageName = uniqid();
     //move_uploaded_file($temp,"images/".$pht);
     if($name) {
       
     $upload= "../University/images/";
            $imgExt=strtolower(pathinfo($name, PATHINFO_EXTENSION));
            $valid_ext= array('jpg','png','jpeg' );
            $userpic= rand(1000,1000000).".".$imgExt;
            unlink($upload.$row['photo']);
            move_uploaded_file($temp,$upload.$userpic);
   }
   else
   {
    $userpic=$result['photo'];
   }


 $query=mysqli_query($con,"update admin_login set
 username='".$_POST['name']."',
 email='".$_POST['email']."',
 photo='".$userpic."',
 password='".$_POST['password']."'
  

 
 where  id='".$_GET['id']."' ") or die(mysqli_error($con));
 if($query)
                          {
       echo '<script type="text/javascript">';
       echo " alert('Updated Successfully');";
       echo 'window.location.href = "view-profile.php";';
       echo '</script>';
  
                      }
                     else
                     {
       echo '<script type="text/javascript">';
       echo "alert('Not updated.');";
        echo 'window.location.href = "view-profile.php";';
                        
         echo '<script>';
                      
  
                     }
}


?>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                    include 'footer.php';

                ?>