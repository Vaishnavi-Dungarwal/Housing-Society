<?php
 include 'header.php';
?>
                <div class="content-wrapper">
                    <h3 class="text-primary mb-4">Society Details</h3>
                    

                    <div class="row mb-2">
                        <div class="col-md-12 col-xs-12">
                            <div class="card">
                                <div class="card-block">
                                    <!-- <h5 class="card-title mb-4">Advanced Table</h5> -->
                                    <div class="table-responsive">
                                        <table id="example" class="table table-hover" cellspacing="0" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>Sn</th>
                                                    <th>Society Name</th>           
                                                    <th>Contact</th>
                                                    <th>Registration Code</th>
                                                    <th>Photo</th>
                                                    <th>Address</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>

                                            <tbody>
                                                    <?php
                                                    include 'connection.php';
                                                    $disp=mysqli_query($con,"select * from society ") or die(mysqli_error($con));
                                                    $count=0;
                                                    while ($fetch=mysqli_fetch_array($disp))
                                                     {
                                                            extract($fetch);


                                                ?>  
                                                    <tr>
                                                        <td><?php echo ++$count; ?></td>
                                                        <td><?php echo $fetch['society_name'];?></td>
                                                        <td><?php echo $fetch['contact'];?></td>
                                                        <td><?php echo $fetch['registration_code'];?></td>                                                       
                                                        <td><img src="../Images/Society/<?php echo $fetch['photo']; ?>" height="80" width="80"></td>
                                                        <td><?php echo $fetch['address'];?></td>
                                                        
                                                        
                                                        <td>                                          
                                                                                                    
                <a href="view_user_list.php?society_email=<?=$email ?>" class="fa fa-eye fa-2x text-primary" type="submit" name="View"  data-placement="bottom" title="View" data-toggle="tooltip" style="padding-left:10px"></a>


        <!-- <a href="delete_society.php?society_email=<?=$email ?>" onclick="return confirm('Are you sure you want to delete this Society?');" class="fa fa-trash fa-2x text-danger" type="submit" name="delete"  data-placement="bottom" title="Delete" data-toggle="tooltip" style="padding-left:10px"></a> -->
                                                      
                                            
                                                                                                            
                                                        </td>
                                                    </tr>
                                                <?php } ?> 
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            <?php

            include 'footer.php';
            ?>