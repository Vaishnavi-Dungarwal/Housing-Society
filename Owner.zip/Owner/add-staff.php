<?php
include 'header.php';
?>
                
                <div class="content-wrapper">
                    <h3 class="text-primary mb-4">Add Subject</h3>
                    <div class="row mb-2">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-block">
                                    <h5 class="card-title mb-4">New Subject Registration</h5>
                                    <form class="forms-sample" method="post" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Name</label>
                                            <input type="name" name="name" class="form-control p-input" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter name" required="">
                                            <small id="emailHelp" class="form-text text-muted text-success"></small>
                                        </div>
                                        

                                        <div class="col-12">
                                            <button type="submit" name="add" class="btn btn-primary">Submit</button>
                                        </div>
<?php
include('connection.php');
if(isset($_POST['add']))
{
  extract($_POST);

  // $df=uniqid();

  //     $exname=$_FILES['file']['name'];
  //     $size=$_FILES['file']['size'];
  //     $type=$_FILES['file']['type'];
  //     $temp=$_FILES['file']['tmp_name'];
  //     $dst="".$df.$exname;
  //     move_uploaded_file($temp,"images/".$dst);

  $df=uniqid();

      $exename=$_FILES['file']['name'];
      $size=$_FILES['file']['size'];
      $type=$_FILES['file']['type'];
      $temp=$_FILES['file']['tmp_name'];
      $dst="".$df.$exename;
      move_uploaded_file($temp,"images/".$dst);


  $query=mysqli_query($con,"INSERT INTO college (name,email,contact,photo,aff_code,center_code,address,password,year,status) VALUES ('$name','$email','$contact','$dst','$aff_code','$center_code','$address','$password','$year','Approved') ") or die(mysqli_error($con));
  if ($query)
   {
     echo "<script>";
      echo "alert('College Added Successfully');";
      echo "window.location.href='add-college.php'";
      echo "</script";
  }
  else
    {
      echo "<script>";
      echo "alert('Not Added. Please try again');";
      echo "window.location.href='add-college.php'";
      echo "</script";
    }

}
?>






                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                    include 'footer.php';

                ?>


                <script src="js/jquery-2.1.4.min.js"></script>
    <script type="text/javascript">
$(document).ready(function(){
  $("select#vehicle_type").change(function(){
        var d = $("#vehicle_type option:selected").val();
    
        $.ajax({
            type: "POST",
            url: "model.php", 
            data: { vehicle_type : d  } 
        }).done(function(data){
            $("#vehicle_name").html(data);
        });
    });
});
</script>


<script type="text/javascript">
$(document).ready(function(){
  $("select#vehicle_name").change(function(){
        var d = $("#vehicle_name option:selected").val();
    
        $.ajax({
            type: "POST",
            url: "model1.php", 
            data: { vehicle_name : d  } 
        }).done(function(data){
            $("#vehicle_model").html(data);
        });
    });
});
</script>