<?php
include 'header.php';
?>
                
                <div class="content-wrapper">
                    <h3 class="text-primary mb-4">Add Society</h3>
                    <div class="row mb-2">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-block">
                                    <h5 class="card-title mb-4">New Society Registration</h5>
                                    <form class="forms-sample" method="post" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Society Name</label>
                                            <input type="text" name="name" class="form-control p-input" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter society name" required="required">
                                            <small id="emailHelp" class="form-text text-muted text-success"></small>
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Email</label>
                                            <input type="email" name="email" class="form-control p-input" id="exampleInputPassword1" placeholder="Enter email" required="required">
                                        </div>

                                        
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Contact</label>
                                            <input type="text" name="contact" class="form-control p-input" id="exampleInputPassword1" placeholder="Enter contact starting with 0,7,8,9" required="required" minlength="10" maxlength="11" pattern="[7|8|9][0-9]{9}" >
                                        </div>
                                                                                                             
                                      <div class="form-group">
                                            <label for="exampleInputPassword1">Registration Code</label>
                                            <input type="text" name="reg_code" class="form-control p-input" id="exampleInputPassword1" placeholder="Enter Registration Code" required="required">
                                        </div>

                                       <div class="form-group">
                                            <label for="exampleTextarea">Address</label>
                                            <textarea name="address" class="form-control p-input" id="exampleTextarea" rows="3" required="required"></textarea>
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleInputFile">Photo</label>
                                            <input type="file" name="file" class="form-control-file" id="exampleInputFile" aria-describedby="fileHelp" required="required">
                                            
                                        </div>
                                        
                                       
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Password</label>
                                            <input type="password" name="password" class="form-control p-input" id="exampleInputPassword1" placeholder="Enter password" required="required">
                                        </div>

                                        


                                        <div class="col-12">
                                            <button type="submit" name="add" class="btn btn-primary">Add</button>
                                            <a href="home.php" class="btn btn-danger">Cancel</a>
                                        </div>
<?php
include('connection.php');
if(isset($_POST['add']))
{
  extract($_POST);


  $df=uniqid();

      $exename=$_FILES['file']['name'];
      $size=$_FILES['file']['size'];
      $type=$_FILES['file']['type'];
      $temp=$_FILES['file']['tmp_name'];
      $dst="".$df.$exename;
      move_uploaded_file($temp,"../Images/Society/".$dst);


$coulmn=array();
  $query11=mysqli_query($con,"select email from society");
    while ($row11=mysqli_fetch_assoc($query11))
    {
      $coulmn[]=$row11['email'];
    }

      foreach ($coulmn as $value) 
      {

       if (strpos($email, $value) !== FALSE ) 
       {
        echo '<script type="text/javascript">'; 
      echo 'alert("This Email Address Is Already Exist. Please Register with another Email Address");';
      echo "window.location.href = 'add-society.php';";
      echo '</script>'; 
        return true;

       }
    
      }




  $query=mysqli_query($con,"INSERT INTO society (society_name,email,contact,registration_code,address,photo,password) VALUES ('$name','$email','$contact','$reg_code','$address','$dst','$password') ") or die(mysqli_error($con));
  if ($query)
   {
     echo "<script>";
      echo "alert('Society Added Successfully');";
      echo "window.location.href='add-society.php'";
      echo "</script";
  }
  else
    {
      echo "<script>";
      echo "alert('Not Added. Please try again');";
      echo "window.location.href='add-society.php'";
      echo "</script";
    }

}
?>






                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                    include 'footer.php';

                ?>