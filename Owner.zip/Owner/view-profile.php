<?php
 include 'header.php';
?>
                <div class="content-wrapper">
                    <h3 class="text-primary mb-4">Profile</h3>
                    

                    <div class="row mb-2">
                        <div class="col-md-12 col-xs-12">
                            <div class="card">
                                <div class="card-block">
                                    <!-- <h5 class="card-title mb-4">Advanced Table</h5> -->
                                    <div class="table-responsive">
                                        <table id="example" class="table table-hover" cellspacing="0" width="100%">
                                            <thead>
                                                <tr>
                                                    <!-- <th>Id</th> -->
                                                    <th>Name</th>               
                                                    <th>Email</th>
                                                    <th>Photo</th>
                                                    <th>Password</th>                   
                                                    <th>Action</th>

                                                </tr>
                                            </thead>

                                            <tbody>
                                                    <?php
                                                    include 'connection.php';
                                                    $disp=mysqli_query($con,"select * from admin_login") or die(mysqli_error($con));
                                                    $count=0;
                                                    while ($fetch=mysqli_fetch_array($disp))
                                                     {
                                                            extract($fetch);


                                                ?>  
                                                    <tr>
                                                        <!-- <td><?php //echo $id ?></td> -->
                                                        <td><?php echo $fetch['username'];?></td>
                                                        <td><?php echo $fetch['email'];?></td>
                                                                                                              
                                                        <td><img src="../University/images/<?php echo $fetch['photo']; ?>" height="80" width="80"></td>
                                                        <td><?php echo $fetch['password'];?></td>
                                                        
                                                        <td>

                                                        <a href="update_profile.php?id=<?=$id ?>" class="fa fa-edit fa-2x text-warning" type="submit" name="Update"  data-placement="bottom" title="Update" data-toggle="tooltip" style="padding-left:10px"></a>
                                            
                                                                                                            
                                                        <a href="delete_admin.php?id=<?=$id ?>"  onclick="return confirm('Are you sure you want to delete this Admin?');"  class="fa fa-trash-o fa-2x text-danger" type="submit" name="delete" style="padding-left:10px" data-placement="bottom" title="delete" data-toggle="tooltip"></a></td>
                                                    </tr>
                                                <?php } ?> 
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            <?php

            include 'footer.php';
            ?>