

<?php
include 'connection.php';
  if(isset($_GET['society_email']))

  {
          

        $sel=mysqli_query($con,"select * from society where email='".$_GET['society_email']."' ");
        while ($fetch=mysqli_fetch_array($sel))
         {
          $img=$fetch["photo"];         
         
        }

          $isrc="../Images/Society/".$img;
                    
          unlink($isrc);        
        
          $query= 'delete from society where email="'.$_GET['society_email'].'" ' ;
          $result = mysqli_query($con,$query);
         
   if($result)
   {
      
             echo '<script type="text/javascript">';
       echo " alert('Society Record Deleted');";
      echo 'window.location.href = "view_society.php";';
       echo '</script>';
   }
   else
    {
      echo '<script type="text/javascript">';
       echo " alert('Society Record Not Deleted');";
       echo 'window.location.href = "view_society.php";';
       echo '</script>';
    }

 }