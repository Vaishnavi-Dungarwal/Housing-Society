<?php
session_start();
if(!isset($_SESSION['email']))
{
    header('location:index.php');   
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Registered Users Details</title>
    <link rel="stylesheet" href="../node_modules/font-awesome/css/font-awesome.min.css" />
    <link rel="stylesheet" href="../node_modules/perfect-scrollbar/dist/css/perfect-scrollbar.min.css" />
    <link rel="stylesheet" href="../css/style.css" />
    <link rel="shortcut icon" href="../images/favicon.png" />
    <link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"></style>
    <script src="../node_modules/jquery/dist/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
</head>

<body>

    <?php
        include "config.php";
        $disp=mysqli_query($connect,"select * from user where Status ='Not_approved' ") or die(mysqli_error($connect));

    ?> 

    <div class=" container-scroller">
          <!--Start Navbar -->
            <?php include "navbar.php";?>
        <!--End navbar-->
        
        <div class="container-fluid">
            <div class="row row-offcanvas row-offcanvas-right">
                 <!-- START SIDEBAR  -->
                    <?php include "sidebar.php";?>
                <!-- ENDS SIDEBAR  -->


                <div class="content-wrapper">
                    <h3 class="text-primary mb-4">Registered Users Details</h3>
                    

                    <div class="row mb-2">
                        <div class="col-md-12 col-xs-12">
                            <div class="card">
                                <div class="card-block">
                                    <!-- <h5 class="card-title mb-4">Advanced Table</h5> -->
                                    <div class="table-responsive">
                                        <table id="example" class="table table-hover" cellspacing="0" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>Sr.No</th>
                                                    <th>Id</th>
                                                    <th>Name</th>                                                    
                                                    <th>Email</th>
                                                    <!-- <th>Mobile</th> -->
                                                    <th>Username</th>
                                                    <th>Password</th>
                                                    <th>Status</th>
                                                    <th>Action</th>

                                                </tr>
                                            </thead>

                                            <tbody>
                                                    <?php
                                                    $count=0;
                                                    while ($fetch=mysqli_fetch_array($disp))
                                                     {
                                                            extract($fetch);


                                                ?>  
                                                    <tr>
                                                        <td><?php echo ++$count;?></td>
                                                        <td><?php echo $fetch['id'];?></td>
                                                        <td><?php echo $fetch['Name'];?></td>
                                                        <td><?php echo $fetch['Email'];?></td>
                                                        <!-- <td><?php //echo $fetch['Mobile'];?></td> -->
                                                        <td><?php echo $fetch['Username'];?></td>
                                                        <td><?php echo $fetch['Password'];?></td>
                                                        <td><?php echo $fetch['Status'];?></td>
                                                        <td><a href="reg_approve.php?id=<?=$id ?>" class="fa fa-thumbs-o-up fa-2x text-success" type="submit" name="view"  data-placement="bottom" title="approve" data-toggle="tooltip"></a>
                                            
                                                        <a href="reg_disapprove.php?id=<?=$id ?>" class="fa fa-thumbs-o-down fa-2x text-danger" type="submit" name="view"  data-placement="bottom" title="disapprove" data-toggle="tooltip" style="padding-left:10px"></a>
                                            
                                                        <a href="view.php?id=<?=$id ?>" class="fa fa-eye fa-2x text-info" type="submit" name="view"  data-placement="bottom" title="view" data-toggle="tooltip" style="padding-left:10px"></a>
                                            
                                                                                                            
                                                        <a href="delete.php?id=<?=$id ?>"  onclick="return confirm('Are you sure you want to delete this item?');"  class="fa fa-trash-o fa-2x text-danger" type="submit" name="delete" style="padding-left:10px" data-placement="bottom" title="delete" data-toggle="tooltip"></a></td>
                                                    </tr>
                                                <?php } ?> 
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                

               <!-- start footer -->
                    <?php include "footer.php";?>
                <!-- end footer -->
            </div>
        </div>

    </div>



    <script src="../node_modules/tether/dist/js/tether.min.js"></script>
    <script src="../node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="../node_modules/chart.js/dist/Chart.min.js"></script>
    <script src="../node_modules/perfect-scrollbar/dist/js/perfect-scrollbar.jquery.min.js"></script>
    <script src="../js/off-canvas.js"></script>
    <script src="../js/hoverable-collapse.js"></script>
    <script src="../js/misc.js"></script>

<script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>

<script>
$(document).ready(function(){
    $('#example').dataTable();
});
</script>
</body>

</html>