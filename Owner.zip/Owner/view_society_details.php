<?php
include 'header.php';
?>
                
                <div class="content-wrapper">
                    <h3 class="text-primary mb-4">View College</h3>
                    <div class="row mb-2">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-block">
                                   <?php
                                              include 'connection.php';
  if(isset($_GET['id']))
  {
   
   
   $query = mysqli_query($con,"select * from society where id='".$_GET['id']."' ") or die(mysqli_error($con));
      
          $result = mysqli_fetch_array($query);
          extract($result);
  
  
    ?>


                                    <h5 class="card-title mb-4">View Society</h5>
                                    <form class="forms-sample" method="post" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Society Name</label>
                                            <input type="text" name="name" class="form-control p-input" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo $result['society_name']; ?>" disabled>
                                            <small id="emailHelp" class="form-text text-muted text-success"></small>
                                        </div>


                                        <div class="form-group">                                        
                                            <label for="exampleInputEmail1">Email</label>
                                            <input type="email" name="email" class="form-control p-input" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo $result['email']; ?>" disabled>
                                            
                                        </div>



                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Contact</label>
                                            <input type="email" class="form-control p-input" id="exampleInputPassword1" value="<?php echo $result['contact']; ?>" disabled>
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Registration Code</label>
                                            <input type="text" name="contact" class="form-control p-input" id="exampleInputPassword1" value="<?php echo $result['contact']; ?>" disabled>
                                        </div>
                                                                                                                                                       
                                       
                                        
                                        <div class="form-group">
                                            <label for="exampleTextarea">Address</label>
                                            <textarea name="address" class="form-control p-input" id="exampleTextarea" rows="3" disabled><?php echo $result['address']; ?></textarea>
                                        </div>


                                         <div class="form-group">
                                            <label for="exampleInputFile">Photo</label>
                                            
                                            <img src="../Images/Society/<?php echo $result['photo']?>" height="120" width="120" disabled>
                                            
                                        </div>



                                    
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Password</label>
                                            <input type="password" name="password" class="form-control p-input" id="exampleInputPassword1" value="<?php echo $result['password']; ?>" disabled>
                                        </div>

                                        
                                        <div class="col-12">
                                            <a href="view_society.php"><input type="button" class="btn btn-primary" value="Back"></a>
                                        </div>

                               </form>
                               <?php
                             }
                           
                           ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                    include 'footer.php';

                ?>