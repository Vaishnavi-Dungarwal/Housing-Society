<?php
 include 'header.php';
?>
                <div class="content-wrapper">
                    <h3 class="text-primary mb-4">Print</h3>
                    

                    <div class="row mb-2">
                        <div class="col-md-12 col-xs-12">
                            <div class="card">
                                <div class="card-block">
                                    <!-- <h5 class="card-title mb-4">Advanced Table</h5> -->
                                    <div class="table-responsive">
                                        <table id="example" class="table table-hover" cellspacing="0" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>Sn.</th>
                                                    <th>Department</th>
                                                    <th>Year</th>
                                                    <th>Subject</th>
                                                    <th>Date</th>
                                                    <th>From Time</th>
                                                    <th>To Time</th>              
                                                    
                                                    <th>Action</th>

                                                </tr>
                                            </thead>

                                            <tbody>
                                                    <?php
                                                    include 'connection.php';
                                                    $disp=mysqli_query($con,"select * from date_time") or die(mysqli_error($con));
                                                    $count=0;
                                                    while ($fetch=mysqli_fetch_array($disp))
                                                     {
                                                            extract($fetch);


                                                ?>  
                                                    <tr>
                                                        <td><?php echo ++$count; ?></td>
                                                        <td><?php echo $fetch['department'];?></td>

                                                        <td><?php echo $fetch['year'];?></td>
                                                        <td><?php echo $fetch['subject'];?>
                                                            
                                                        </td>
                                                        
                                                        

                                                        <td><?php echo $fetch['set_date'];?>
                                                            
                                                        </td>
                                                        
                                                       


                                                        <td><?php echo $fetch['from_time'];?>
                                                            
                                                        </td>

                                                        <td><?php echo $fetch['to_time'];?>
                                                            
                                                        </td>
                                                        
                                                        <td>
                        <a href="update_datetime.php?id=<?=$id ?>" class="fa fa-edit fa-2x text-success" type="submit" name="Update"  data-placement="bottom" title="Update" data-toggle="tooltip" style="padding-left:10px"></a>
                                           
<a href="delete_print.php?id=<?=$id ?>" onclick="return confirm('Are you sure you want to delete this Record?');" class="fa fa-trash fa-2x text-danget" type="submit" name="delete" style="padding-left:10px" data-placement="bottom" title="Delete" data-toggle="tooltip"></a>


                                                                                                            
<a href="print.php?department=<?=$department?>&year=<?=$year?>&subject=<?=$subject?>" class="fa fa-print fa-2x text-warning" type="submit" name="print" style="padding-left:10px" data-placement="bottom" title="Print" data-toggle="tooltip"></a></td>
                                                    </tr>
                                                <?php } ?> 
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            <?php

            include 'footer.php';
            ?>