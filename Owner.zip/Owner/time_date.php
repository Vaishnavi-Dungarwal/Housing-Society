<?php
include 'header.php';

?>

                
                <div class="content-wrapper">
                    <h3 class="text-primary mb-4">Set Time</h3>
                    <div class="row mb-2">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card">
                                <div class="card-block">
                                   
                                    <form class="forms-sample" method="post" enctype="multipart/form-data">
                                    <div class="form-group">
                                            <label for="exampleInputEmail1">Department</label>
                                            
                                            <select class="form-control p-input" id="department" name="department" aria-describedby="emailHelp" required>
                    <option value="">---Select Department---</option>
                                                <?php
               $query="select DISTINCT department from question_paper";
              
               $res=mysqli_query($con,$query);
                    while($row=mysqli_fetch_array($res))
                        {
                          ?>
                          <option value="<?php echo $row['department']; ?>"><?php echo $row['department'];  ?></option>
                               <?php
                                        }
                                ?>
                      </select>
                                        </div>


                                        
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Year</label>
                                            

                                            <select class="form-control p-input" id="year" name="year" aria-describedby="emailHelp" required>
                    <option value="">---Select Year---</option>
                                                
                      </select>
                                        </div>






                                       <div class="form-group">
                                            <label for="exampleInputPassword1">Subject</label>                          
                                            <select class="form-control p-input" id="subject" name="subject" aria-describedby="emailHelp" required>
                    <option value="">---Select Subject---</option>
                                                
                      </select>
                                        </div>






                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Date</label>
                                            <input type="text" name="date" class="form-control p-input" id="date" aria-describedby="emailHelp" placeholder="Enter date" required>
                                            
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleInputEmail1">From Time</label>
                                            <input type="time" name="from_time" class="form-control p-input" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter from time" required>
                                            
                                        </div>



                                        <div class="form-group">
                                            <label for="exampleInputEmail1">To Time</label>
                                            <input type="time" name="to_time" class="form-control p-input" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter to_time" required>
                                            
                                        </div>




                                        <div class="col-12">
                                            <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                                            <a href="home.php" class="btn btn-danger">Cancel</a>
                                        </div>
<?php
include('connection.php');
if(isset($_POST['submit']))
{
  extract($_POST);
  date_default_timezone_set("Asia/Kolkata");

 $query=mysqli_query($con,"INSERT INTO date_time (department,year,subject,set_date,from_time,to_time) VALUES ('$department','$year','$subject','$date','$from_time','$to_time') ") or die(mysqli_error($con));
  if ($query)
   {
     echo "<script>";
      echo "alert('Submited Successfully');";
      echo "window.location.href='time_date.php'";
      echo "</script";
  }
  else
    {
      echo "<script>";
      echo "alert('Not Submited. Please try again');";
      echo "window.location.href='time_date.php'";
      echo "</script";
    }

}
?>
                                   </form>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
                </form>

                



                <?php
                    include 'footer.php';

                ?>

                <script src="js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="js/plugins/select2.min.js"></script>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>


                
    <script type="text/javascript">
$(document).ready(function(){
  $("select#department").change(function(){
        var d = $("#department option:selected").val();
    
        $.ajax({
            type: "POST",
            url: "model-time.php", 
            data: { department : d  } 
        }).done(function(data){
            $("#year").html(data);
        });
    });
});
</script>


<script type="text/javascript">
$(document).ready(function(){
  $("select#year").change(function(){
        var d = $("#year option:selected").val();
    
        $.ajax({
            type: "POST",
            url: "model1-time.php", 
            data: { year : d  } 
        }).done(function(data){
            $("#subject").html(data);
        });
    });
});
</script>


<script type="text/javascript">
$(document).ready(function(){
  $("select#subject").change(function(){
        var d = $("#subject option:selected").val();
    
        $.ajax({
            type: "POST",
            url: "model2-select-university.php", 
            data: { subject : d  } 
        }).done(function(data){
            $("#marks").html(data);
        });
    });
});
</script>




<script>

    $(document).ready(function(){
        var date_input=$('input[name="date"]'); //our date input has the name "date"
        var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
        date_input.datepicker({
            format: 'yyyy-mm-dd',
            container: container,
            todayHighlight: true,
            autoclose: true,
        })
    })
</script>

















