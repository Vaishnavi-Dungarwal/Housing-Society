<?php
 include 'header.php';
?>
                <div class="content-wrapper">
                    <h3 class="text-primary mb-4">User Details</h3>
                    

                    <div class="row mb-2">
                        <div class="col-md-12 col-xs-12">
                            <div class="card">
                                <div class="card-block">
                                    <!-- <h5 class="card-title mb-4">Advanced Table</h5> -->
                                    <div class="table-responsive">
                                        <table id="example" class="table table-hover" cellspacing="0" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>Sn</th>
                                                    <th>User Name</th>           
                                                    <th>Email</th>
                                                    <th>Contact</th>
                                                    <th>Flat No</th>
                                                    <!-- <th>Action</th> -->
                                                </tr>
                                            </thead>

                                            <tbody>
                                                    <?php
                                                    include 'connection.php';
                                                    $disp=mysqli_query($con,"select * from user where society_email='".$_GET['society_email']."' ") or die(mysqli_error($con));
                                                    $count=0;
                                                    while ($fetch=mysqli_fetch_array($disp))
                                                     {
                                                            extract($fetch);


                                                ?>  
                                                    <tr>
                                                        <td><?php echo ++$count; ?></td>
                                                        <td><?php echo $fetch['name'];?></td>
                                                        <td><?php echo $fetch['email'];?></td>
                                                        <td><?php echo $fetch['contact'];?></td>
                                                        <td><?php echo $fetch['flat_no'];?></td>                                     <!-- <td>                                    
                                                                                                    
                                                        <a href="view_society_details.php?id=<?=$id ?>" class="fa fa-eye fa-2x text-primary" type="submit" name="view"  data-placement="bottom" title="view" data-toggle="tooltip" style="padding-left:10px"></a>

                                                        <a href="update_society.php?id=<?=$id ?>" class="fa fa-edit fa-2x text-warning" type="submit" name="Update"  data-placement="bottom" title="Update" data-toggle="tooltip" style="padding-left:10px"></a>
                                            
                                                                                                            
                                                        <a href="delete_society.php?id=<?=$id ?>"  onclick="return confirm('Are you sure you want to delete this Society record?');"  class="fa fa-trash-o fa-2x text-danger" type="submit" name="delete" style="padding-left:10px" data-placement="bottom" title="delete" data-toggle="tooltip"></a>

                                                    </td> -->
                                                    
                                                    </tr>
                                                <?php } ?> 
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            <?php

            include 'footer.php';
            ?>