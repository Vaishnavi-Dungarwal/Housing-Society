

<?php
include 'connection.php';
  if(isset($_GET['id']))

  {
          

        $sel=mysqli_query($con,"select * from admin_login where id='".$_GET['id']."' ");
        while ($fetch=mysqli_fetch_array($sel))
         {
          $img=$fetch["photo"];         
         
        }

          $isrc="../University/images/".$img;
                    
          unlink($isrc);        
        
          $query= 'delete from admin_login where id="'.$_GET['id'].'" ' ;
          $result = mysqli_query($con,$query);
         
   if($result)
   {
      
             echo '<script type="text/javascript">';
       echo " alert('Record Deleted');";
       echo 'window.location.href = "index.php";';
       echo '</script>';
   }
   else
    {
      echo '<script type="text/javascript">';
       echo " alert('College Record Not Deleted');";
       echo 'window.location.href = "view-profile.php";';
       echo '</script>';
    }

 }