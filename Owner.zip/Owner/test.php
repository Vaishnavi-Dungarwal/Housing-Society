<div class="row">
  <div class="col-4">
  4
  </div>
  <div class="col-4">
  4
  </div>
  <div class="col-4">
  4
  </div>

</div>