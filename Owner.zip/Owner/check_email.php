<?php
error_reporting(0);
include ("connection.php");
// $db_handle = new DBController();


if(!empty($_POST["email"])) {
  $result = mysqli_query($con,"SELECT count(*) FROM society WHERE email='" . $_POST["email"] . "'") or die (mysqli_error($con));
  $row = mysqli_fetch_row($result);
  $user_count = $row[0];
  if($user_count>0) {
      echo "<span class='status-not-available'> Email Exist..Please try one another </span>";
  }else{
      echo "<span class='status-available'>Email is Available.</span>";
  }
}
?>