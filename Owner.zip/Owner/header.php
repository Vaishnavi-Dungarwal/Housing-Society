<?php

include "connection.php";
session_start();
if(!isset($_SESSION['email']))
{
         echo "<script>";
         echo "window.location.href='index.php';";
         echo "</script>";
   
}

?>
<!DOCTYPE html>
<html lang="en">

  <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title>Admin</title>
      <link rel="stylesheet" href="node_modules/font-awesome/css/font-awesome.min.css" />
      <link rel="stylesheet" href="node_modules/perfect-scrollbar/dist/css/perfect-scrollbar.min.css" />
      <link rel="stylesheet" href="css/style.css"/>
      <link rel="shortcut icon" href="images/favicon.png"/>
      <link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css">
      <script src="../node_modules/jquery/dist/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
  <script type="text/javascript" src="jquery-1.3.2.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>


<LINK href="style.css" rel="stylesheet" type="text/css" />
<SCRIPT src="http://code.jquery.com/jquery-2.1.1.js"></SCRIPT>
<SCRIPT>
function addMore() {
  $("<DIV>").load("input.php", function() {
      $("#product").append($(this).html());
  }); 
}
function deleteRow() {
  $('DIV.product-item').each(function(index, item){
    jQuery(':checkbox', this).each(function () {
            if ($(this).is(':checked')) {
        $(item).remove();
            }
        });
  });
}



</SCRIPT>





<SCRIPT>
function addMore1() {
  $("<DIV>").load("add_print_university.php", function() {
      $("#product1").append($(this).html());
  }); 
}
function deleteRow1() {
  $('DIV.product-item').each(function(index, item){
    jQuery(':checkbox', this).each(function () {
            if ($(this).is(':checked')) {
        $(item).remove();
            }
        });
  });
}
</SCRIPT>





<script language="javascript">
function printdiv(printpage)
{
var headstr = "<html><head><title></title></head><body>";
var footstr = "</body>";
var newstr = document.all.item(printpage).innerHTML;
var oldstr = document.body.innerHTML;
document.body.innerHTML = headstr+newstr+footstr;
window.print();
document.body.innerHTML = oldstr;
return false;
}
</script>


  </head>
  <body>
      <div class=" container-scroller">
        <!--Navbar-->
        <nav class="navbar bg-primary-gradient col-lg-12 col-12 p-0 fixed-top navbar-inverse d-flex flex-row">
            <div class="bg-white text-center navbar-brand-wrapper">
                <a class="navbar-brand brand-logo" href="home.php"><img src="images/logo_star_black.png" /></a>
                <a class="navbar-brand brand-logo-mini" href="home.php"><img src="images/logo_star_mini.jpg" alt=""></a>
            </div>
            <div class="navbar-menu-wrapper d-flex align-items-center">
                <button class="navbar-toggler navbar-toggler hidden-md-down align-self-center mr-3" type="button" data-toggle="minimize">
                  <span class="navbar-toggler-icon"></span>
                </button>
                
                <ul class="navbar-nav ml-lg-auto d-flex align-items-center flex-row">
                    <li class="nav-item">
                    <?php
          include 'connection.php';

            $query = mysqli_query($con,"select * from owner where email='".$_SESSION['email']."' ");
            if(mysqli_num_rows($query)>0)
                {
                    while($result=mysqli_fetch_assoc($query))
                      {
                          extract($result);
        ?>
                        <!-- <a class="nav-link profile-pic"><img class="rounded-circle" src="images/<?php echo $result['photo']; ?>" alt=""></a> -->
                    </li>
                    
                   <!--  <li class="nav-item">
                        <a class="nav-link" href="#"><i class="fa fa-th"></i></a>
                    </li> -->
                </ul>
                <button class="navbar-toggler navbar-toggler-right hidden-lg-up align-self-center" type="button" data-toggle="offcanvas">
                  <span class="navbar-toggler-icon"></span>
                </button>
            </div>
        </nav>
        <!--End navbar-->
        <div class="container-fluid">
            <div class="row row-offcanvas row-offcanvas-right">
                <nav class="bg-white sidebar sidebar-fixed sidebar-offcanvas" id="sidebar">
                <div class="user-info">

                    <img src="../Images/Owner/admin.png" alt="Admin Image">
        
                    <p class="name"><?php echo $result['name']; ?></p>
                    <p class="designation">Admin</p>
                    <span class="online"></span>
                </div>
                <?php
            }
        }
                ?>
                    <ul class="nav">
                        <li class="nav-item active">
                            <a class="nav-link" href="home.php">
                                <!-- <i class="fa fa-dashboard"></i> -->
                                <img src="images/icons/1.png" alt="">
                                <span class="menu-title">Dashboard</span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" data-toggle="collapse" href="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                                <!-- <i class="fa fa-address-book"></i> -->
                                <img src="images/icons/college.png" alt="">
                                <span class="menu-title">Society<i class="fa fa-sort-down"></i></span>
                            </a>
                            <div class="collapse" id="collapseExample">
                                <ul class="nav flex-column sub-menu">
                                    <li class="nav-item">
                                        <a class="nav-link" href="add-society.php">
                                      Add Society
                                    </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link" href="view_society.php">
                                      View Society
                                    </a>
                                    </li>
                                    
                                    
                                </ul>
                            </div>
                        </li>  




                        <li class="nav-item">
                            <a class="nav-link" data-toggle="collapse" href="#collapseExample1" aria-expanded="false" aria-controls="collapseExample1">
                                <!-- <i class="fa fa-address-book"></i> -->
                                <img src="images/icons/college.png" alt="">
                                <span class="menu-title">User<i class="fa fa-sort-down"></i></span>
                            </a>
                            <div class="collapse" id="collapseExample1">
                                <ul class="nav flex-column sub-menu">
                                   <!--  <li class="nav-item">
                                        <a class="nav-link" href="add-society.php">
                                      Add Society
                                    </a>
                                    </li> -->
                                    
                                    <li class="nav-item">
                                        <a class="nav-link" href="view_user_by_society.php">
                                      View User
                                    </a>
                                    </li>
                                    
                                    
                                </ul>
                            </div>
                        </li> 



                      <li class="nav-item">
                            <a class="nav-link" data-toggle="collapse" href="#collapseExample11" aria-expanded="false" aria-controls="collapseExample11">
                                <!-- <i class="fa fa-address-book"></i> -->
                                <img src="images/icons/college.png" alt="">
                                <span class="menu-title">Tax<i class="fa fa-sort-down"></i></span>
                            </a>
                            <div class="collapse" id="collapseExample11">
                                <ul class="nav flex-column sub-menu">
                                   <!--  <li class="nav-item">
                                        <a class="nav-link" href="add-society.php">
                                      Add Society
                                    </a>
                                    </li> -->
                                    
                                    <li class="nav-item">
                                        <a class="nav-link" href="view_paid.php">
                                      Paid Tax
                                    </a>
                                    </li>
                                    
                                    
                                </ul>
                            </div>
                        </li> 


                        <li class="nav-item">
                            <a class="nav-link" href="view_notification.php">
                                <!-- <i class="fa fa-bold"></i> -->
                                <img src="../Images/key.jpg" alt="">
                                <span class="menu-title">Notification</span>
                            </a>
                        </li>



                       <li class="nav-item">
                            <a class="nav-link" href="change_password.php">
                                <!-- <i class="fa fa-bold"></i> -->
                                <img src="../Images/key.jpg" alt="">
                                <span class="menu-title">Change Password</span>
                            </a>
                        </li>
                                  
                        
                   
                       
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                <!-- <i class="fa fa-bold"></i> -->
                                <img src="images/icons/logout.jpg" alt="">
                                <span class="menu-title" onclick="return confirm('Are you sure you want to logout from Owner account?');">Logout</span>
                            </a>
                        </li>
                    </ul>
                </nav>
                <!-- SIDEBAR ENDS -->