<?php
include 'header.php';
?>
                
                <div class="content-wrapper">
                    <h3 class="text-primary mb-4">Add Title</h3>
                    <div class="row mb-2">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-block">
                                    <!-- <h5 class="card-title mb-4">New College Registration</h5> -->
                                    <form class="forms-sample" method="post" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">title</label>
                                            <input type="text" name="title" class="form-control p-input" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter title" required="required">
                                            <small id="emailHelp" class="form-text text-muted text-success"></small>
                                        </div>
                                                                            
                                        <div class="col-12">
                                            <button type="submit" name="add" class="btn btn-primary">Add</button>
                                            <a href="home.php" class="btn btn-danger">Cancel</a>
                                        </div>
<?php
include('connection.php');
if(isset($_POST['add']))
{
  extract($_POST);
  $query=mysqli_query($con,"INSERT INTO question_paper (question_number,title,number_of_questions,number_of_marks) VALUES ('','$title','','') ") or die(mysqli_error($con));
  if ($query)
   {
     echo "<script>";
      echo "alert('Added Successfully');";
      echo "window.location.href='add-title.php'";
      echo "</script";
  }
  else
    {
      echo "<script>";
      echo "alert('Not Added. Please try again');";
      echo "window.location.href='add-title.php'";
      echo "</script";
    }

}
?>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                    include 'footer.php';

                ?>