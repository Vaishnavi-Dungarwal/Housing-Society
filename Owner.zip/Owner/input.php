

<DIV class="product-item float-clear" style="clear:both;">&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<DIV class="float-left"><input type="checkbox" name="item_index[]" ></DIV>
<DIV class="float-left"><input type="text" name="marks[]" placeholder="Enter Marks Weightage" required /></DIV><br><br>
<DIV class="float-left" ><input type="text" name="questions[]" placeholder="Enter number of questions" / style="margin-left: 15px;" required></DIV>
</DIV>






                      
                          		<!-- 		<div class="form-group" id='TextBoxesGroup'>
                                             <div id="TextBoxDiv1">
                                              <label for="exampleInputEmail1">Marks Waightage</label>
                                              <input type="text" name="marks[]" class="form-control p-input" id='textbox1' aria-describedby="emailHelp" placeholder="Enter Marks Waightage" required>
                                              <small id="emailHelp" class="form-text text-muted text-success"></small>
                                              
                                            </div>
                                        </div> 



                                        <div class="form-group" id='TextBoxesGroup1'>
                                        <div id="TextBoxDiv1">
                                            <label for="exampleInputPassword5">Number of Questions</label>
                                            <input type="text" name="questions[]" class="form-control p-input" id="exampleInputPassword5" placeholder="Enter number of questions" required>
                                            
                                        </div>
                                        </div>  -->




