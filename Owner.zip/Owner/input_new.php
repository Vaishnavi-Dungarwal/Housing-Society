<DIV class="product-item float-clear" style="clear:both;">
<div class="form-group" id='TextBoxesGroup'>
                                             <div id="TextBoxDiv1">
                                              <label for="exampleInputEmail1">Marks Waightage</label>
                                              <input type="text" name="marks[]" class="form-control p-input" id='textbox1' aria-describedby="emailHelp" placeholder="Enter Marks Waightage">
                                              <small id="emailHelp" class="form-text text-muted text-success"></small>
                                              
                                            </div>
                                        </div>



                                        <div class="form-group" id='TextBoxesGroup1'>
                                        <div id="TextBoxDiv1">
                                            <label for="exampleInputPassword5">Number of Questions</label>
                                            <input type="text" name="questions[]" class="form-control p-input" id="exampleInputPassword5" placeholder="Enter number of questions">
                                            
                                        </div>
                                        </div>
                                        </DIV>